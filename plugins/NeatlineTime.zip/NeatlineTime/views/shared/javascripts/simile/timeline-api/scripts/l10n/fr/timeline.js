Timeline.strings.fr={wikiLinkLabel:"Discute"};
