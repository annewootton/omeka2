Timeline.GregorianDateLabeller.monthNames.tr="Ock,\u015ebt,Mrt,Nsn,Mys,Hzr,Tem,A\u011fs,Eyl,Ekm,Ksm,Arl".split(",");
