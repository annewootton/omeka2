Timeline.strings.se={wikiLinkLabel:"Discuss"};
