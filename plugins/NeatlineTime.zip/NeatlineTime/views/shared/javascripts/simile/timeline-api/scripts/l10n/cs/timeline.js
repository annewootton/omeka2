Timeline.strings.cs={wikiLinkLabel:"Diskuze"};
