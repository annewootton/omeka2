Timeline.strings.de={wikiLinkLabel:"Diskutieren"};
