Timeline.strings.zh={wikiLinkLabel:"\u8ba8\u8bba"};
