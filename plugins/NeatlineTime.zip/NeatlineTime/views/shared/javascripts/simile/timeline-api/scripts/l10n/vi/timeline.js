Timeline.strings.vi={wikiLinkLabel:"Ba\u0300n lu\u00e2\u0323n"};
