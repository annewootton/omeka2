Timeline.strings.tr={wikiLinkLabel:"Tart\u0131\u015f"};
