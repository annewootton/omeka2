<?php
/**
 * ExhibitPageEntry table class
 * 
 * @version $Id$
 * @copyright Center for History and New Media, 2007-20009
 * @license http://www.gnu.org/licenses/gpl-3.0.txt
 * @package Omeka
 * @author CHNM
 **/

class ExhibitPageEntryTable extends Omeka_Db_Table
{
    protected $_name = 'items_section_pages';
}