<fieldset class="form-gallery-thumbs">
	<?php
	for($i=1; $i <= 16; $i++):
    	echo exhibit_builder_layout_form_item($i);	    
	endfor;
	?>
</fieldset>
