<div class="gallery-thumbnails">
	<div class="primary">
	<?php echo exhibit_builder_display_exhibit_thumbnail_gallery(1, 16, array('class'=>'permalink')); ?>
	</div>
</div>