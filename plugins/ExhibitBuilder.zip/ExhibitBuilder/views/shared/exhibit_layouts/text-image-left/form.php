<fieldset class="<?php echo $layout; ?>">
	<?php 
	    echo exhibit_builder_layout_form_item(1);
	    echo exhibit_builder_layout_form_text(1);
    ?>
</fieldset>
