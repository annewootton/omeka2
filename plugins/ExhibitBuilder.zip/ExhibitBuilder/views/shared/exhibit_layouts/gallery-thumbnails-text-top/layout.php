<div class="gallery-thumbnails-text-top">
	<div class="primary">
		<div class="exhibit-text">
		<?php echo exhibit_builder_page_text(1); ?>
		</div>
	</div>
	<div class="secondary">
	    <?php echo exhibit_builder_display_exhibit_thumbnail_gallery(1, 12, array('class'=>'permalink')); ?>
	</div>
</div>